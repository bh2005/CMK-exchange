# Interface SMA (Simple Moving Average) Check Plugin for Checkmk 2.4+

## Problem

Checkmk's built-in interface bandwidth averaging uses an **Exponentially Weighted
Moving Average (EWMA)**. While memory-efficient, EWMA converges asymptotically:
after one averaging period at constant load, it only reaches ~63% of the actual
value. This makes time-critical alerting on sustained interface overload unreliable.

## Solution

This plugin implements a **true Simple Moving Average (SMA)** — the arithmetic mean
of all samples within the configured time window. After exactly N minutes of
sustained load, the SMA reflects the actual load. No asymptotic convergence delay.

| Scenario: 100% load sustained | EWMA (built-in) | SMA (this plugin) |
|-------------------------------|------------------|-------------------|
| After 1x averaging period     | ~63%             | 100%              |
| After 2x averaging period     | ~86%             | 100%              |
| After 3x averaging period     | ~95%             | 100%              |

## Features

- Works with **SNMP-based** (switches, routers) and **agent-based** (Linux, Windows) interfaces
- No additional SNMP walks — reuses existing `interfaces` section data
- Configurable via WATO GUI (averaging window, WARN/CRIT thresholds per direction)
- Creates **additional** services alongside standard interface checks
- Includes graphs, perfometer, and metric definitions
- Handles 64-bit counter wraps

## Deployment

As site user on the Checkmk server:

```bash
# Create plugin directories
mkdir -p ~/local/lib/python3/cmk_addons/plugins/if_sma/agent_based
mkdir -p ~/local/lib/python3/cmk_addons/plugins/if_sma/rulesets
mkdir -p ~/local/lib/python3/cmk_addons/plugins/if_sma/graphing

# Copy plugin files
cp agent_based/if_sma.py     ~/local/lib/python3/cmk_addons/plugins/if_sma/agent_based/
cp rulesets/ruleset_if_sma.py ~/local/lib/python3/cmk_addons/plugins/if_sma/rulesets/
cp graphing/if_sma_graphing.py ~/local/lib/python3/cmk_addons/plugins/if_sma/graphing/

# Restart the site to load the new plugin
omd restart
```

## Configuration

1. Run a **service discovery** on your switches/hosts — new "IF SMA ..." services will appear
2. Configure thresholds via:
   **Setup > Services > Service monitoring rules > Interface SMA (Simple Moving Average) Bandwidth**
3. Set the averaging window (default: 15 minutes) and WARN/CRIT levels

## Example

With `averaging_minutes: 15` and `levels_upper_total_pct: (80, 90)`:

- Interface at 100% for 15 minutes → SMA shows 100% → **CRIT**
- Interface at 50% for 15 minutes → SMA shows 50% → **OK**
- Interface spikes to 100% for 5 minutes then drops → SMA adjusts immediately

## Notes

- The plugin stores sample history in the Checkmk ValueStore (persistent across restarts)
- Sample history is automatically pruned to the configured window
- Memory usage scales with `(window_minutes / check_interval)` samples per interface
- At 60s check interval with 15min window = ~15 samples per interface (negligible)
- At 60s check interval with 60min window = ~60 samples per interface (still fine)

## Requirements

- Checkmk 2.4.0 or newer (uses Check API v2 and Rulesets API v1)
- The standard "interfaces" section must be available (it is by default for SNMP and agent-based hosts)

## Files

```
~/local/lib/python3/cmk_addons/plugins/if_sma/
├── agent_based/
│   └── if_sma.py              # Main check plugin
├── rulesets/
│   └── ruleset_if_sma.py      # WATO rule for GUI configuration
└── graphing/
    └── if_sma_graphing.py     # Metrics, graphs, perfometer
```
```
