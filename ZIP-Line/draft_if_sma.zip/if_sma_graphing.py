#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (C) 2026 - License: GNU General Public License v2
#
# Graphing definitions for Interface SMA Check
#
# Deploy to:
#   ~/local/lib/python3/cmk_addons/plugins/if_sma/graphing/if_sma_graphing.py
#

from cmk.graphing.v1 import graphs, metrics, perfometers, Title

# ──────────────────────────────────────────────────────────────────────
# Metric definitions
# ──────────────────────────────────────────────────────────────────────
metric_if_sma_in_bps = metrics.Metric(
    name="if_sma_in_bps",
    title=Title("SMA Inbound bandwidth"),
    unit=metrics.Unit(metrics.DecimalNotation("bit/s")),
    color=metrics.Color.BLUE,
)

metric_if_sma_out_bps = metrics.Metric(
    name="if_sma_out_bps",
    title=Title("SMA Outbound bandwidth"),
    unit=metrics.Unit(metrics.DecimalNotation("bit/s")),
    color=metrics.Color.GREEN,
)

metric_if_sma_in_pct = metrics.Metric(
    name="if_sma_in_pct",
    title=Title("SMA Inbound utilization"),
    unit=metrics.Unit(metrics.DecimalNotation("%")),
    color=metrics.Color.BLUE,
)

metric_if_sma_out_pct = metrics.Metric(
    name="if_sma_out_pct",
    title=Title("SMA Outbound utilization"),
    unit=metrics.Unit(metrics.DecimalNotation("%")),
    color=metrics.Color.GREEN,
)

metric_if_sma_max_pct = metrics.Metric(
    name="if_sma_max_pct",
    title=Title("SMA Max utilization"),
    unit=metrics.Unit(metrics.DecimalNotation("%")),
    color=metrics.Color.ORANGE,
)

metric_if_sma_samples = metrics.Metric(
    name="if_sma_samples",
    title=Title("SMA Sample count"),
    unit=metrics.Unit(metrics.DecimalNotation("")),
    color=metrics.Color.GRAY,
)

# ──────────────────────────────────────────────────────────────────────
# Graph definitions
# ──────────────────────────────────────────────────────────────────────
graph_if_sma_bandwidth = graphs.Graph(
    name="if_sma_bandwidth",
    title=Title("SMA Interface Bandwidth"),
    compound_lines=[
        "if_sma_in_bps",
        "if_sma_out_bps",
    ],
)

graph_if_sma_utilization = graphs.Graph(
    name="if_sma_utilization",
    title=Title("SMA Interface Utilization"),
    compound_lines=[
        "if_sma_in_pct",
        "if_sma_out_pct",
        "if_sma_max_pct",
    ],
    simple_lines=[
        metrics.WarningOf("if_sma_max_pct"),
        metrics.CriticalOf("if_sma_max_pct"),
    ],
)

# ──────────────────────────────────────────────────────────────────────
# Perfometer
# ──────────────────────────────────────────────────────────────────────
perfometer_if_sma = perfometers.Perfometer(
    name="if_sma",
    focus_range=perfometers.FocusRange(
        perfometers.Closed(0),
        perfometers.Closed(100),
    ),
    segments=["if_sma_max_pct"],
)
