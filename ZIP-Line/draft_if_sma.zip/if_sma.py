#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (C) 2026 - License: GNU General Public License v2
#
# Interface Simple Moving Average (SMA) Check Plugin for Checkmk 2.4+
#
# This plugin creates additional services that calculate a true Simple Moving
# Average for interface bandwidth, instead of the built-in EWMA.
#
# Works with both SNMP-based (switches) and agent-based interfaces.
# No additional SNMP walks or agent plugins needed — it reuses the
# existing "interfaces" section data.
#
# Deploy to:
#   ~/local/lib/python3/cmk_addons/plugins/if_sma/agent_based/if_sma.py
#

import json
import time
from collections.abc import Mapping
from typing import Any

from cmk.agent_based.v2 import (
    CheckPlugin,
    CheckResult,
    DiscoveryResult,
    Metric,
    Result,
    Service,
    State,
    check_levels,
    get_value_store,
    render,
)

# We import the already-parsed interfaces section.
# This works for SNMP (switches, routers) AND agent-based (Linux, Windows) interfaces.
# No need to define our own section — we piggyback on the standard one.

# ──────────────────────────────────────────────────────────────────────
# Default parameters — can be overridden via WATO rule
# ──────────────────────────────────────────────────────────────────────
DEFAULT_PARAMETERS: dict[str, Any] = {
    "averaging_minutes": 15,
    "levels_upper_in_pct": (80.0, 90.0),    # WARN/CRIT for inbound utilization %
    "levels_upper_out_pct": (80.0, 90.0),   # WARN/CRIT for outbound utilization %
    "levels_upper_total_pct": (80.0, 90.0), # WARN/CRIT for max(in, out) utilization %
}


# ──────────────────────────────────────────────────────────────────────
# Helper: Calculate rate from counter values
# ──────────────────────────────────────────────────────────────────────
def _get_rate(
    value_store: dict,
    key: str,
    now: float,
    counter_value: float,
) -> float | None:
    """Calculate rate (per second) from monotonically increasing counter.
    Returns None if this is the first measurement or counter wrapped.
    """
    prev_key = f"_rate_prev_{key}"
    prev = value_store.get(prev_key)

    # Store current value for next run
    value_store[prev_key] = json.dumps({"time": now, "value": counter_value})

    if prev is None:
        return None

    try:
        prev_data = json.loads(prev) if isinstance(prev, str) else prev
        prev_time = prev_data["time"]
        prev_value = prev_data["value"]
    except (json.JSONDecodeError, KeyError, TypeError):
        return None

    time_delta = now - prev_time
    if time_delta <= 0:
        return None

    value_delta = counter_value - prev_value

    # Handle counter wrap (assume 64-bit counter)
    if value_delta < 0:
        value_delta += 2**64

    return value_delta / time_delta


# ──────────────────────────────────────────────────────────────────────
# Helper: Simple Moving Average over a time window
# ──────────────────────────────────────────────────────────────────────
def _calculate_sma(
    value_store: dict,
    key: str,
    now: float,
    current_value: float,
    window_seconds: float,
) -> tuple[float, int]:
    """Store sample and return (average, sample_count) over the window.

    Unlike EWMA, this is a true arithmetic mean of all samples within
    the time window. After exactly <window_seconds> at a constant value,
    the SMA will show that exact value — no asymptotic convergence.
    """
    history_key = f"_sma_history_{key}"
    raw = value_store.get(history_key)

    try:
        history = json.loads(raw) if isinstance(raw, str) else []
    except (json.JSONDecodeError, TypeError):
        history = []

    # Append current sample
    history.append({"t": round(now, 1), "v": round(current_value, 2)})

    # Remove samples outside the window
    cutoff = now - window_seconds
    history = [h for h in history if h["t"] >= cutoff]

    # Limit history size to prevent unbounded growth
    # (at 60s interval, 60 min window = max 60 samples; add some margin)
    max_samples = int(window_seconds / 30) + 10
    if len(history) > max_samples:
        history = history[-max_samples:]

    # Store
    value_store[history_key] = json.dumps(history)

    if not history:
        return 0.0, 0

    avg = sum(h["v"] for h in history) / len(history)
    return avg, len(history)


# ──────────────────────────────────────────────────────────────────────
# Discovery function
# ──────────────────────────────────────────────────────────────────────
def discover_if_sma(section: Any) -> DiscoveryResult:
    """Discover interfaces that are operational (up) and have a known speed.

    We only create SMA services for interfaces that:
    - are operationally up (oper_status == '1')
    - have a known speed > 0
    - have a description or alias (for meaningful service names)
    """
    if not section:
        return

    for interface in section:
        # interface is an InterfaceWithCounters namedtuple from the interfaces section
        attrs = interface.attributes if hasattr(interface, 'attributes') else interface

        # Get operational status — '1' means up
        oper_status = getattr(attrs, 'oper_status', None)
        if oper_status is None:
            oper_status = getattr(attrs, 'oper_status_name', None)

        # Try to determine if interface is up
        is_up = False
        if isinstance(oper_status, str):
            is_up = oper_status in ('1', 'up')
        elif isinstance(oper_status, int):
            is_up = oper_status == 1

        speed = getattr(attrs, 'speed', 0) or 0

        # Get a meaningful name for the service
        descr = getattr(attrs, 'descr', '') or ''
        alias = getattr(attrs, 'alias', '') or ''
        index = getattr(attrs, 'index', '') or ''

        item = descr or alias or index
        if not item:
            continue

        if is_up and speed > 0:
            yield Service(item=item)


# ──────────────────────────────────────────────────────────────────────
# Check function
# ──────────────────────────────────────────────────────────────────────
def check_if_sma(item: str, params: Mapping[str, Any], section: Any) -> CheckResult:
    """Calculate Simple Moving Average for interface bandwidth and check levels."""

    if not section:
        yield Result(state=State.UNKNOWN, summary="No interface data")
        return

    # Find our interface
    interface = None
    for iface in section:
        attrs = iface.attributes if hasattr(iface, 'attributes') else iface
        descr = getattr(attrs, 'descr', '') or ''
        alias = getattr(attrs, 'alias', '') or ''
        index = getattr(attrs, 'index', '') or ''

        if item in (descr, alias, index):
            interface = iface
            break

    if interface is None:
        yield Result(state=State.UNKNOWN, summary=f"Interface '{item}' not found")
        return

    attrs = interface.attributes if hasattr(interface, 'attributes') else interface
    counters = interface.counters if hasattr(interface, 'counters') else interface

    speed = getattr(attrs, 'speed', 0) or 0
    if not speed:
        yield Result(state=State.UNKNOWN, summary="Interface speed unknown")
        return

    # Get counter values (bytes)
    in_octets = getattr(counters, 'in_octets', 0) or 0
    out_octets = getattr(counters, 'out_octets', 0) or 0

    now = time.time()
    value_store = get_value_store()

    # Calculate rates (bytes/sec) from counters
    in_rate = _get_rate(value_store, "in_octets", now, in_octets)
    out_rate = _get_rate(value_store, "out_octets", now, out_octets)

    if in_rate is None or out_rate is None:
        yield Result(state=State.OK, summary="Waiting for first rate calculation...")
        return

    # Convert to bits/sec
    in_bps = in_rate * 8
    out_bps = out_rate * 8

    # Parameters
    avg_minutes = params.get("averaging_minutes", 15)
    window_seconds = avg_minutes * 60

    # Calculate SMA
    avg_in_bps, samples_in = _calculate_sma(
        value_store, "in_bps", now, in_bps, window_seconds
    )
    avg_out_bps, samples_out = _calculate_sma(
        value_store, "out_bps", now, out_bps, window_seconds
    )

    samples = min(samples_in, samples_out)

    # Calculate utilization percentages
    # speed is in bits/sec in the interfaces section
    in_pct = (avg_in_bps / speed) * 100 if speed else 0
    out_pct = (avg_out_bps / speed) * 100 if speed else 0
    max_pct = max(in_pct, out_pct)

    # Get levels
    warn_crit_in = params.get("levels_upper_in_pct", (80.0, 90.0))
    warn_crit_out = params.get("levels_upper_out_pct", (80.0, 90.0))
    warn_crit_total = params.get("levels_upper_total_pct", (80.0, 90.0))

    # Check levels on max utilization (primary alert)
    yield from check_levels(
        max_pct,
        levels_upper=("fixed", warn_crit_total),
        label=f"SMA({avg_minutes}min) max utilization",
        render_function=render.percent,
    )

    # Summary with bandwidth values
    yield Result(
        state=State.OK,
        notice=(
            f"In: {render.networkbandwidth(avg_in_bps)} ({in_pct:.1f}%), "
            f"Out: {render.networkbandwidth(avg_out_bps)} ({out_pct:.1f}%), "
            f"Samples: {samples}, Window: {avg_minutes}min, "
            f"Speed: {render.networkbandwidth(speed)}"
        ),
    )

    # Metrics for graphing
    yield Metric("if_sma_in_bps", avg_in_bps)
    yield Metric("if_sma_out_bps", avg_out_bps)
    yield Metric("if_sma_in_pct", in_pct, levels=warn_crit_in)
    yield Metric("if_sma_out_pct", out_pct, levels=warn_crit_out)
    yield Metric("if_sma_max_pct", max_pct, levels=warn_crit_total)
    yield Metric("if_sma_samples", samples)


# ──────────────────────────────────────────────────────────────────────
# Plugin registration
# ──────────────────────────────────────────────────────────────────────
check_plugin_if_sma = CheckPlugin(
    name="if_sma",
    sections=["interfaces"],
    service_name="IF SMA %s",
    discovery_function=discover_if_sma,
    check_function=check_if_sma,
    check_default_parameters=DEFAULT_PARAMETERS,
    check_ruleset_name="if_sma",
)
