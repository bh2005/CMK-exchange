#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (C) 2026 - License: GNU General Public License v2
#
# WATO Ruleset for Interface SMA Check
#
# Deploy to:
#   ~/local/lib/python3/cmk_addons/plugins/if_sma/rulesets/ruleset_if_sma.py
#

from cmk.rulesets.v1 import Help, Title
from cmk.rulesets.v1.form_specs import (
    DefaultValue,
    DictElement,
    Dictionary,
    Float,
    Integer,
    LevelDirection,
    SimpleLevels,
)
from cmk.rulesets.v1.rule_specs import CheckParameters, HostAndItemCondition, Topic


rule_spec_if_sma = CheckParameters(
    name="if_sma",
    title=Title("Interface SMA (Simple Moving Average) Bandwidth"),
    topic=Topic.NETWORKING,
    parameter_form=lambda: Dictionary(
        title=Title("SMA Parameters"),
        help_text=Help(
            "Configure the Simple Moving Average (SMA) calculation for interface "
            "bandwidth monitoring. Unlike the built-in EWMA, SMA calculates a true "
            "arithmetic mean over the configured time window. This means: after exactly "
            "N minutes of sustained load, the average will reflect the actual load — "
            "no asymptotic convergence delay."
        ),
        elements={
            "averaging_minutes": DictElement(
                required=True,
                parameter_form=Integer(
                    title=Title("Averaging window (minutes)"),
                    help_text=Help(
                        "Number of minutes to average over. The SMA will calculate "
                        "the arithmetic mean of all samples within this time window. "
                        "Example: With 15 minutes, if the interface is at 100%% for "
                        "15 minutes, the SMA will show 100%% — not ~63%% like EWMA."
                    ),
                    prefill=DefaultValue(15),
                    custom_validate=(lambda v: None if 1 <= v <= 1440 else (_ for _ in ()).throw(ValueError("Must be between 1 and 1440 minutes"))),
                ),
            ),
            "levels_upper_in_pct": DictElement(
                required=False,
                parameter_form=SimpleLevels(
                    title=Title("Upper levels for inbound utilization"),
                    help_text=Help(
                        "Set WARN/CRIT thresholds for inbound bandwidth utilization "
                        "as percentage of interface speed."
                    ),
                    level_direction=LevelDirection.UPPER,
                    form_spec_template=Float(unit_symbol="%"),
                    prefill_fixed_levels=DefaultValue((80.0, 90.0)),
                ),
            ),
            "levels_upper_out_pct": DictElement(
                required=False,
                parameter_form=SimpleLevels(
                    title=Title("Upper levels for outbound utilization"),
                    help_text=Help(
                        "Set WARN/CRIT thresholds for outbound bandwidth utilization "
                        "as percentage of interface speed."
                    ),
                    level_direction=LevelDirection.UPPER,
                    form_spec_template=Float(unit_symbol="%"),
                    prefill_fixed_levels=DefaultValue((80.0, 90.0)),
                ),
            ),
            "levels_upper_total_pct": DictElement(
                required=True,
                parameter_form=SimpleLevels(
                    title=Title("Upper levels for max(in, out) utilization"),
                    help_text=Help(
                        "Set WARN/CRIT thresholds for the maximum of inbound and "
                        "outbound bandwidth utilization. This is the primary metric "
                        "used for alerting."
                    ),
                    level_direction=LevelDirection.UPPER,
                    form_spec_template=Float(unit_symbol="%"),
                    prefill_fixed_levels=DefaultValue((80.0, 90.0)),
                ),
            ),
        },
    ),
    condition=HostAndItemCondition(item_title=Title("Interface name")),
)
