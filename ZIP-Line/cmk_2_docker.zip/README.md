# Checkmk Migration Playbook
## Native Linux → Docker (Server A → Server B)

Automates the migration described in the Checkmk forum thread:
https://forum.checkmk.com/t/migrating-from-a-regular-linux-host-to-a-docker-host/57550

---

## Prerequisites

### Ansible Controller (your workstation or jump host)

```bash
# Install Ansible and Docker SDK
pip install ansible docker

# Install required Ansible collections
ansible-galaxy collection install community.docker

# Verify
ansible --version      # >= 2.14 recommended
```

### Server A (source — native Linux Checkmk)
- Root SSH access from the Ansible controller
- OMD / Checkmk installed and site running
- Enough disk space in `/tmp` for the backup archive

### Server B (target — Docker host)
- Root SSH access from the Ansible controller
- Ubuntu 22.04 or 24.04 (adjust apt repo in `deploy_docker` for other distros)
- Internet access to pull the Checkmk Docker image
- Ports `8080` and `8000` available

---

## Configuration

Edit `group_vars/all.yml`:

```yaml
cmk_site_name: "mysite"        # your actual site name
cmk_version: "2.4.0-latest"    # must match your source version!
cmk_edition: "raw"             # raw | cloud | enterprise
cmk_admin_password: "secret"   # only used if password reset needed
docker_http_port: 8080
```

Edit `inventory.ini`:
```ini
[checkmk_source]
server_a ansible_host=192.168.1.10

[checkmk_target]
server_b ansible_host=192.168.1.20
```

---

## Usage

### Full migration (all 3 phases)
```bash
ansible-playbook -i inventory.ini migrate_checkmk.yml
```

### Dry run first (recommended)
```bash
ansible-playbook -i inventory.ini migrate_checkmk.yml --check
```

### Run individual phases
```bash
# Phase 1 only: backup on Server A
ansible-playbook -i inventory.ini migrate_checkmk.yml --tags phase1

# Phase 2 only: Docker setup on Server B
ansible-playbook -i inventory.ini migrate_checkmk.yml --tags phase2

# Phase 3 only: restore (backup must already be on the controller at /tmp/cmk_migration/)
ansible-playbook -i inventory.ini migrate_checkmk.yml --tags phase3

# Skip Docker install if already present
ansible-playbook -i inventory.ini migrate_checkmk.yml --skip-tags docker_install
```

### Keep source site running during backup
```bash
ansible-playbook -i inventory.ini migrate_checkmk.yml \
  -e "keep_source_stopped=false"
```

---

## What the playbook does

```
PHASE 1 — Server A (source)
├── Check OMD site exists
├── Stop the site (for consistent backup)
├── omd backup mysite /tmp/cmk_migration/cmk_mysite_migration.tar.gz
├── Fetch backup to Ansible controller (/tmp/cmk_migration/)
└── Restart source site (optional)

PHASE 2 — Server B (target)
├── Install Docker Engine + Compose plugin
├── Create /opt/cmk-data/{sites,backup}
├── Write docker-compose.yml with CMK_SITE_ID=mysite
├── Pull checkmk/check-mk-raw:2.4.0-latest
└── Start container → creates empty site

PHASE 3 — Server B (inside container)
├── Copy backup into container via docker cp
├── omd stop mysite
├── omd restore --reuse --kill /tmp/backup.tar.gz
├── *** Fix cmk_docker.conf (the forum post's key issue) ***
├── omd config set APACHE_TCP_ADDR 0.0.0.0
├── omd start mysite
└── Verify HTTP 200 on web UI
```

---

## Project structure

```
checkmk_migration/
├── migrate_checkmk.yml               ← Main playbook
├── inventory.ini                     ← Server A + B addresses
├── group_vars/
│   └── all.yml                       ← All shared variables
└── roles/
    ├── backup_source/
    │   └── tasks/main.yml            ← Phase 1: backup on Server A
    ├── deploy_docker/
    │   └── tasks/main.yml            ← Phase 2: Docker setup on Server B
    └── restore_site/
        └── tasks/main.yml            ← Phase 3: restore + fix Apache
```

---

## Troubleshooting

### Web UI not reachable after restore
The `cmk_docker.conf` fix in Phase 3 should handle this automatically.
If it still fails, run manually inside the container:
```bash
docker exec -it checkmk bash
omd config mysite set APACHE_TCP_ADDR 0.0.0.0
omd config mysite set APACHE_TCP_PORT 5000
omd restart mysite
```

### Version mismatch error during restore
The Docker image version must match the source site version exactly.
```bash
# Check source version
ssh root@server_a "omd version"

# Then set in group_vars/all.yml:
cmk_version: "2.3.0p18-latest"   # match exactly
```

### omd restore fails with "permission denied on tmpfs"
Add `cap_add: [SYS_ADMIN]` to the docker-compose.yml services block,
or use the `--tmpfs` flag when starting the container.

### community.docker collection missing
```bash
ansible-galaxy collection install community.docker
```
