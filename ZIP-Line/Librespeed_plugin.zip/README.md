# LibreSpeed – Check_MK Plugin
## Vollständige Installations- und Deploymentanleitung

---

## Voraussetzungen

### 1. Check_MK Server

| Anforderung | Details |
|---|---|
| Checkmk Version | **2.3.0 oder neuer** (Check API v2 erforderlich) |
| Edition | Raw, Cloud, Standard, Enterprise – alle unterstützt |
| OMD-Site | Aktive Site mit SSH-Zugang |
| Python | Kommt mit Checkmk, kein separates Install nötig |

> **Wichtig:** Plugins aus dieser Anleitung sind **nicht** kompatibel mit Checkmk 2.2.x  
> oder älter (anderer API-Pfad und andere Import-Struktur).

### 2. Überwachter Host (wo der Speedtest laufen soll)

| Anforderung | Details |
|---|---|
| OS | Linux (amd64 / arm64 / armv7) |
| Check_MK Agent | Installiert und aktiv (`check_mk_agent`) |
| librespeed-cli | Muss manuell installiert werden (siehe unten) |
| Netzwerk | Zugang zum LibreSpeed-Server (intern oder öffentlich) |
| Speicher | ~500 MB RAM während des Tests (multi-gigabit) |

---

## Schritt 1: librespeed-cli auf dem Host installieren

```bash
# Architektur ermitteln
ARCH=$(uname -m)
case "$ARCH" in
  x86_64)  ARCH_NAME="amd64" ;;
  aarch64) ARCH_NAME="arm64" ;;
  armv7l)  ARCH_NAME="armv7" ;;
  *)       echo "Unbekannte Architektur: $ARCH"; exit 1 ;;
esac

# Aktuelle Version herunterladen
VERSION=$(curl -s https://api.github.com/repos/librespeed/speedtest-cli/releases/latest \
  | grep '"tag_name"' | cut -d'"' -f4)

wget "https://github.com/librespeed/speedtest-cli/releases/download/${VERSION}/librespeed-cli_${VERSION#v}_linux_${ARCH_NAME}.tar.gz"

# Entpacken und installieren
tar xvzf librespeed-cli_*.tar.gz
sudo mv librespeed-cli /usr/local/bin/
sudo chmod +x /usr/local/bin/librespeed-cli

# Testen
librespeed-cli --version
# → librespeed-cli/1.x.x

# Funktionstest (öffentliche Server)
librespeed-cli --json --no-icmp
```

---

## Schritt 2: LibreSpeed-Server deployen (optional, eigener Server)

Wenn du einen eigenen Server betreiben möchtest:

```bash
# docker-compose.yml
cat > /opt/librespeed/docker-compose.yml << 'EOF'
version: '3.7'
services:
  speedtest:
    image: ghcr.io/librespeed/speedtest:latest
    restart: always
    environment:
      MODE: standalone
      TELEMETRY: "true"
      PASSWORD: "DEIN-PASSWORT"
      EMAIL: "admin@example.com"
    ports:
      - "8080:8080"
EOF

cd /opt/librespeed && docker compose up -d

# Test
curl http://localhost:8080/garbage.php?ckSize=10 | wc -c
# → sollte ~10MB ausgeben
```

---

## Schritt 3: Agent Plugin installieren

```bash
# Auf dem überwachten Host:

# Plugin-Verzeichnis erstellen (mit Cache-Intervall 3600s = 1x/Stunde)
sudo mkdir -p /usr/lib/check_mk_agent/plugins/3600

# Plugin kopieren (von deinem Check_MK-Server oder per SCP)
sudo cp librespeed /usr/lib/check_mk_agent/plugins/3600/
sudo chmod +x /usr/lib/check_mk_agent/plugins/3600/librespeed

# Konfigurationsdatei anlegen (falls eigener Server genutzt wird)
sudo mkdir -p /etc/check_mk
sudo cat > /etc/check_mk/librespeed.cfg << 'EOF'
LIBRESPEED_USE_LOCAL_SERVER="yes"
LIBRESPEED_SERVER_URL="http://speedtest.intern.example.com/"
LIBRESPEED_DURATION="15"
LIBRESPEED_CONCURRENT="3"
LIBRESPEED_NO_ICMP="yes"
EOF

# Plugin manuell testen
/usr/lib/check_mk_agent/plugins/3600/librespeed
# Erwartete Ausgabe:
# <<<librespeed:sep(0)>>>
# {"timestamp":"2025-03-02T14:00:00Z","server":{"name":"Local LibreSpeed",...},"ping":5.2,"jitter":1.1,"download":94500000,"upload":47200000,...}
```

---

## Schritt 4: Check-Plugin auf dem Check_MK-Server installieren

```bash
# Als OMD-Site-User (z.B. "mysite"):
su - mysite

# Verzeichnisstruktur anlegen (WICHTIG: Exakt dieser Pfad für Checkmk >= 2.3!)
mkdir -p ~/local/lib/python3/cmk_addons/plugins/librespeed/{agent_based,rulesets,graphing}

# Dateien kopieren
cp agent_based/librespeed.py  ~/local/lib/python3/cmk_addons/plugins/librespeed/agent_based/
cp rulesets/librespeed.py     ~/local/lib/python3/cmk_addons/plugins/librespeed/rulesets/
cp graphing/librespeed.py     ~/local/lib/python3/cmk_addons/plugins/librespeed/graphing/

# Checkmk neu laden (keine volle Neuinstallation nötig!)
cmk -R
# → "Restart complete"

# Plugin-Syntax prüfen
python3 -c "
import sys
sys.path.insert(0, 'local/lib/python3')
from cmk_addons.plugins.librespeed.agent_based.librespeed import *
print('agent_based OK')
from cmk_addons.plugins.librespeed.rulesets.librespeed import *
print('rulesets OK')
"
```

---

## Schritt 5: Service entdecken

### Via GUI:
1. **Setup → Hosts** → Host auswählen
2. **"Run service discovery"** klicken
3. Service **"LibreSpeed Speedtest"** erscheint unter "Undecided"
4. **"Monitor"** klicken → Service aktivieren
5. **"Activate changes"**

### Via Kommandozeile:
```bash
# Als OMD-Site-User
cmk -I hostname    # Service-Discovery
cmk -R             # Konfiguration neu laden
```

---

## Schritt 6: Schwellwerte in WATO konfigurieren

1. **Setup → Services → Service monitoring rules**
2. Suche nach **"LibreSpeed"**
3. Neue Regel erstellen:

```
Parameter              | WARN        | CRIT
-----------------------|-------------|--------
Download Min.          | < 50 Mbit/s | < 20 Mbit/s
Upload Min.            | < 20 Mbit/s | < 10 Mbit/s
Ping Max.              | > 30 ms     | > 80 ms
Jitter Max.            | > 10 ms     | > 30 ms
```

4. Host-Bedingung setzen (z.B. nur für bestimmte Hosts/Gruppen)
5. Speichern → **Activate changes**

---

## MKP-Paket erstellen (für einfache Weitergabe)

```bash
# Als OMD-Site-User:
# Alle Dateien als MKP bündeln
mkp pack librespeed.manifest

# Inhalt der librespeed.manifest:
cat > librespeed.manifest << 'EOF'
{'author': 'Dein Name',
 'description': 'LibreSpeed self-hosted speedtest monitoring',
 'download_url': 'https://github.com/...',
 'files': {
   'agent_based': ['librespeed.py'],
   'rulesets': ['librespeed.py'],
   'graphing': ['librespeed.py'],
   'agents/plugins': ['librespeed'],
 },
 'name': 'librespeed',
 'title': 'LibreSpeed Speedtest',
 'version': '1.0.0',
 'version.min_required': '2.3.0',
 'version.packaged_on': '2.3.0p1',
}
EOF

mkp pack librespeed.manifest
# → librespeed-1.0.0.mkp

# Installieren auf anderem Server:
mkp install librespeed-1.0.0.mkp
```

---

## Troubleshooting

### Plugin liefert keine Daten

```bash
# Auf dem Host: Plugin direkt ausführen
/usr/lib/check_mk_agent/plugins/3600/librespeed

# Agent-Output prüfen
check_mk_agent | grep -A5 "<<<librespeed"

# Auf dem Check_MK-Server: Agentenausgabe simulieren
echo '<<<librespeed:sep(0)>>>
{"ping":5.2,"jitter":1.1,"download":94500000,"upload":47200000,"server":{"name":"Test"},"client":{"isp":"Example"}}' \
| cmk --checks=librespeed -nv hostname
```

### Service bleibt auf UNKNOWN

```bash
# Plugin-Fehler suchen
cmk -d hostname | grep -A2 librespeed

# Python-Syntax prüfen
python3 ~/local/lib/python3/cmk_addons/plugins/librespeed/agent_based/librespeed.py
```

### librespeed-cli schlägt fehl

```bash
# Ausführlich testen
librespeed-cli --json --no-icmp 2>&1

# Eigenen Server direkt ansprechen
echo '[{"id":1,"name":"test","server":"http://speedtest.lan/",
  "dlURL":"garbage.php","ulURL":"empty.php",
  "pingURL":"empty.php","getIpURL":"getIP.php"}]' \
| librespeed-cli --json --no-icmp --local-json -
```

---

## Verzeichnisstruktur (Gesamtübersicht)

```
Check_MK Server (OMD-Site ~/local/):
└── lib/python3/cmk_addons/plugins/librespeed/
    ├── agent_based/
    │   └── librespeed.py       ← Parser + Check-Logik + Service-Discovery
    ├── rulesets/
    │   └── librespeed.py       ← WATO-GUI für Schwellwerte
    └── graphing/
        └── librespeed.py       ← Metriken + Graphen + Perfometer

Überwachter Host:
├── /usr/lib/check_mk_agent/plugins/3600/
│   └── librespeed              ← Bash-Script (führt librespeed-cli aus)
├── /etc/check_mk/
│   └── librespeed.cfg          ← Konfiguration (Server-URL etc.)
└── /usr/local/bin/
    └── librespeed-cli          ← Binary (von GitHub)
```
