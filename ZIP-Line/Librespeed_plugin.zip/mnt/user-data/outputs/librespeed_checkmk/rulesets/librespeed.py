#!/usr/bin/env python3
# =============================================================================
# LibreSpeed - WATO Ruleset (konfigurierbare Schwellwerte in der GUI)
# =============================================================================
# Ablage auf dem CHECK_MK SERVER (OMD-Site):
#   ~/local/lib/python3/cmk_addons/plugins/librespeed/rulesets/librespeed.py
#
# Checkmk Rulesets API v1 (ab 2.3.0)
# =============================================================================

from cmk.rulesets.v1 import Help, Label, Title
from cmk.rulesets.v1.form_specs import (
    BoundedMagnitude,
    DefaultValue,
    DictElement,
    Dictionary,
    Float,
    InputHint,
    LevelDirection,
    Levels,
    SimpleLevels,
    SimpleLevelsConfigModel,
)
from cmk.rulesets.v1.rule_specs import CheckParameters, HostAndItemCondition, Topic


def _parameter_form_librespeed() -> Dictionary:
    return Dictionary(
        title   = Title("LibreSpeed Speedtest Schwellwerte"),
        help_text = Help(
            "Konfiguriert WARN/CRIT-Schwellwerte für den LibreSpeed Speedtest. "
            "Download und Upload: Alarm wenn der Wert ZU NIEDRIG ist. "
            "Ping und Jitter: Alarm wenn der Wert ZU HOCH ist."
        ),
        elements = {

            # --- Download --------------------------------------------------
            "download_lower": DictElement(
                parameter_form = SimpleLevels(
                    title           = Title("Download Mindestgeschwindigkeit"),
                    help_text       = Help(
                        "Schwellwerte für die Download-Geschwindigkeit in Mbit/s. "
                        "WARN/CRIT wird ausgelöst wenn der gemessene Wert "
                        "UNTER den Schwellwert fällt."
                    ),
                    form_spec_template = Float(
                        unit_symbol    = "Mbit/s",
                        prefill        = InputHint(value=0.0),
                    ),
                    level_direction = LevelDirection.LOWER,
                    prefill_fixed_levels = DefaultValue(
                        value=SimpleLevelsConfigModel(
                            type   = "fixed",
                            levels = (50.0, 20.0),   # WARN < 50, CRIT < 20
                        )
                    ),
                ),
                required = False,
            ),

            # --- Upload ----------------------------------------------------
            "upload_lower": DictElement(
                parameter_form = SimpleLevels(
                    title           = Title("Upload Mindestgeschwindigkeit"),
                    help_text       = Help(
                        "Schwellwerte für die Upload-Geschwindigkeit in Mbit/s. "
                        "WARN/CRIT wird ausgelöst wenn der gemessene Wert "
                        "UNTER den Schwellwert fällt."
                    ),
                    form_spec_template = Float(
                        unit_symbol    = "Mbit/s",
                        prefill        = InputHint(value=0.0),
                    ),
                    level_direction = LevelDirection.LOWER,
                    prefill_fixed_levels = DefaultValue(
                        value=SimpleLevelsConfigModel(
                            type   = "fixed",
                            levels = (20.0, 10.0),   # WARN < 20, CRIT < 10
                        )
                    ),
                ),
                required = False,
            ),

            # --- Ping ------------------------------------------------------
            "ping_upper": DictElement(
                parameter_form = SimpleLevels(
                    title           = Title("Ping Maximalwert"),
                    help_text       = Help(
                        "Schwellwerte für den Ping in Millisekunden. "
                        "WARN/CRIT wird ausgelöst wenn der gemessene Wert "
                        "ÜBER den Schwellwert steigt."
                    ),
                    form_spec_template = Float(
                        unit_symbol    = "ms",
                        prefill        = InputHint(value=0.0),
                    ),
                    level_direction = LevelDirection.UPPER,
                    prefill_fixed_levels = DefaultValue(
                        value=SimpleLevelsConfigModel(
                            type   = "fixed",
                            levels = (30.0, 80.0),   # WARN > 30ms, CRIT > 80ms
                        )
                    ),
                ),
                required = False,
            ),

            # --- Jitter ----------------------------------------------------
            "jitter_upper": DictElement(
                parameter_form = SimpleLevels(
                    title           = Title("Jitter Maximalwert"),
                    help_text       = Help(
                        "Schwellwerte für den Jitter in Millisekunden. "
                        "Hoher Jitter deutet auf eine instabile Verbindung hin. "
                        "WARN/CRIT wird ausgelöst wenn der gemessene Wert "
                        "ÜBER den Schwellwert steigt."
                    ),
                    form_spec_template = Float(
                        unit_symbol    = "ms",
                        prefill        = InputHint(value=0.0),
                    ),
                    level_direction = LevelDirection.UPPER,
                    prefill_fixed_levels = DefaultValue(
                        value=SimpleLevelsConfigModel(
                            type   = "fixed",
                            levels = (10.0, 30.0),   # WARN > 10ms, CRIT > 30ms
                        )
                    ),
                ),
                required = False,
            ),

        },
    )


rule_spec_librespeed = CheckParameters(
    name           = "librespeed",
    title          = Title("LibreSpeed Speedtest"),
    topic          = Topic.NETWORKING,
    parameter_form = _parameter_form_librespeed,
    condition      = HostAndItemCondition(item_title=Title("Service")),
)
