#!/usr/bin/env python3
# =============================================================================
# LibreSpeed - Graphing / Metrik-Definitionen
# =============================================================================
# Ablage auf dem CHECK_MK SERVER (OMD-Site):
#   ~/local/lib/python3/cmk_addons/plugins/librespeed/graphing/librespeed.py
#
# Checkmk Graphing API v1 (ab 2.3.0)
# Definiert: Metriken, Perfometer, kombinierte Graphen
# =============================================================================

from cmk.graphing.v1 import graphs, metrics, perfometers, Title


# =============================================================================
# Metrik-Definitionen
# =============================================================================

metric_download = metrics.Metric(
    name       = "download",
    title      = Title("Download"),
    unit       = metrics.Unit(metrics.DecimalNotation("Mbit/s")),
    color      = metrics.Color.BLUE,
)

metric_upload = metrics.Metric(
    name       = "upload",
    title      = Title("Upload"),
    unit       = metrics.Unit(metrics.DecimalNotation("Mbit/s")),
    color      = metrics.Color.GREEN,
)

metric_ping = metrics.Metric(
    name       = "ping",
    title      = Title("Ping"),
    unit       = metrics.Unit(metrics.DecimalNotation("ms")),
    color      = metrics.Color.ORANGE,
)

metric_jitter = metrics.Metric(
    name       = "jitter",
    title      = Title("Jitter"),
    unit       = metrics.Unit(metrics.DecimalNotation("ms")),
    color      = metrics.Color.YELLOW,
)


# =============================================================================
# Perfometer (kleiner Balken in der Service-Liste)
# Zeigt Download-Geschwindigkeit als Hauptwert
# =============================================================================

perfometer_librespeed = perfometers.Perfometer(
    name            = "librespeed",
    focus_range     = perfometers.FocusRange(
        perfometers.Closed(0),
        perfometers.Open(1000),   # Skalierung bis 1000 Mbit/s
    ),
    segments        = ["download"],
)


# =============================================================================
# Graph: Bandbreite (Download + Upload kombiniert)
# =============================================================================

graph_librespeed_bandwidth = graphs.Graph(
    name        = "librespeed_bandwidth",
    title       = Title("LibreSpeed - Bandbreite"),
    compound_lines = [
        "download",
        "upload",
    ],
)


# =============================================================================
# Graph: Latenz (Ping + Jitter kombiniert)
# =============================================================================

graph_librespeed_latency = graphs.Graph(
    name        = "librespeed_latency",
    title       = Title("LibreSpeed - Latenz"),
    compound_lines = [
        "ping",
        "jitter",
    ],
)
