#!/usr/bin/env python3
# =============================================================================
# LibreSpeed - Check_MK Agent Based Plugin
# =============================================================================
# Check API v2 kompatibel (Checkmk >= 2.3.0)
#
# Ablage auf dem CHECK_MK SERVER (OMD-Site):
#   ~/local/lib/python3/cmk_addons/plugins/librespeed/agent_based/librespeed.py
#
# Unterstützte Checkmk-Versionen: 2.3.x, 2.4.x
# =============================================================================

from __future__ import annotations

import json
from typing import Any

from cmk.agent_based.v2 import (
    AgentSection,
    CheckPlugin,
    CheckResult,
    DiscoveryResult,
    Metric,
    Result,
    Service,
    State,
    StringTable,
    check_levels,
    render,
)

# =============================================================================
# Typen
# =============================================================================

Section = dict[str, Any]

# =============================================================================
# Parse-Funktion
# =============================================================================

def parse_librespeed(string_table: StringTable) -> Section | None:
    """
    Parst die Agentenausgabe (eine JSON-Zeile).

    Erwartetes JSON-Format vom librespeed-cli:
    {
        "timestamp": "2025-03-02T14:00:00.000000Z",
        "server": {"name": "Local LibreSpeed", "url": "http://..."},
        "client": {"ip": "1.2.3.4", "isp": "Example ISP"},
        "ping": 5.23,
        "jitter": 1.12,
        "download": 94500000,   <- in bit/s
        "upload": 47200000      <- in bit/s
    }
    """
    if not string_table:
        return None

    raw = " ".join(string_table[0])
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {"error": f"JSON parse error: {raw[:200]}"}

    return data


# =============================================================================
# Discovery
# =============================================================================

def discover_librespeed(section: Section) -> DiscoveryResult:
    """Erstellt genau einen Service wenn Daten vorhanden sind."""
    if section and "error" not in section:
        yield Service()


# =============================================================================
# Check-Funktion
# =============================================================================

def check_librespeed(params: dict, section: Section) -> CheckResult:
    """
    Bewertet die Speedtest-Ergebnisse gegen konfigurierbare Schwellwerte.

    Metriken:
        download   Mbit/s  → WARN/CRIT wenn ZU NIEDRIG  (levels_lower)
        upload     Mbit/s  → WARN/CRIT wenn ZU NIEDRIG  (levels_lower)
        ping       ms      → WARN/CRIT wenn ZU HOCH     (levels_upper)
        jitter     ms      → WARN/CRIT wenn ZU HOCH     (levels_upper)
    """

    # --- Fehlerbehandlung ----------------------------------------------------
    if "error" in section:
        yield Result(
            state=State.CRIT,
            summary=f"Speedtest fehlgeschlagen: {section['error']}",
        )
        return

    # --- Werte extrahieren ---------------------------------------------------
    # librespeed-cli liefert Download/Upload in bit/s
    download_bits = section.get("download", 0)
    upload_bits   = section.get("upload",   0)
    ping_ms       = section.get("ping",     0.0)
    jitter_ms     = section.get("jitter",   0.0)

    # Umrechnung in Mbit/s für lesbare Ausgabe
    download_mbps = download_bits / 1_000_000
    upload_mbps   = upload_bits   / 1_000_000

    # --- Zusatzinfos für die Summary -----------------------------------------
    server_name = section.get("server", {}).get("name", "unbekannt")
    isp         = section.get("client", {}).get("isp", "")
    timestamp   = section.get("timestamp", "")[:19].replace("T", " ")  # "2025-03-02 14:00:00"

    # --- Download prüfen (lower = zu niedrig ist schlecht) -------------------
    yield from check_levels(
        value          = download_mbps,
        metric_name    = "download",
        levels_lower   = params.get("download_lower"),
        label          = "Download",
        render_func    = lambda v: f"{v:.1f} Mbit/s",
    )

    # --- Upload prüfen -------------------------------------------------------
    yield from check_levels(
        value          = upload_mbps,
        metric_name    = "upload",
        levels_lower   = params.get("upload_lower"),
        label          = "Upload",
        render_func    = lambda v: f"{v:.1f} Mbit/s",
    )

    # --- Ping prüfen (upper = zu hoch ist schlecht) --------------------------
    yield from check_levels(
        value          = ping_ms,
        metric_name    = "ping",
        levels_upper   = params.get("ping_upper"),
        label          = "Ping",
        render_func    = lambda v: f"{v:.1f} ms",
    )

    # --- Jitter prüfen -------------------------------------------------------
    yield from check_levels(
        value          = jitter_ms,
        metric_name    = "jitter",
        levels_upper   = params.get("jitter_upper"),
        label          = "Jitter",
        render_func    = lambda v: f"{v:.1f} ms",
    )

    # --- Zusatzinfos (erscheinen im Detail-View) -----------------------------
    if server_name:
        yield Result(state=State.OK, notice=f"Server: {server_name}")
    if isp:
        yield Result(state=State.OK, notice=f"ISP: {isp}")
    if timestamp:
        yield Result(state=State.OK, notice=f"Messung: {timestamp} UTC")


# =============================================================================
# Plugin-Registrierung
# =============================================================================

agent_section_librespeed = AgentSection(
    name           = "librespeed",
    parse_function = parse_librespeed,
)

check_plugin_librespeed = CheckPlugin(
    name                    = "librespeed",
    service_name            = "LibreSpeed Speedtest",
    discovery_function      = discover_librespeed,
    check_function          = check_librespeed,
    check_ruleset_name      = "librespeed",
    # Standardwerte (falls keine WATO-Regel konfiguriert)
    check_default_parameters = {
        "download_lower": (50.0,  20.0),   # WARN < 50 Mbit/s, CRIT < 20 Mbit/s
        "upload_lower":   (20.0,  10.0),   # WARN < 20 Mbit/s, CRIT < 10 Mbit/s
        "ping_upper":     (30.0,  80.0),   # WARN > 30 ms,     CRIT > 80 ms
        "jitter_upper":   (10.0,  30.0),   # WARN > 10 ms,     CRIT > 30 ms
    },
)
